// The Eternal Gallery - Museum Gemstone Art Website

import React from "react";

export default function EternalGallery() {
  return (
    <div style={{
      backgroundColor: 'black',
      color: 'white',
      minHeight: '100vh',
      fontFamily: 'serif',
      textAlign: 'center'
    }}>
      <section style={{
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        padding: '2rem',
        backgroundSize: 'cover',
        backgroundImage: "url('/hero-gemstone.jpg')"
      }}>
        <h1 style={{ fontSize: '4rem', fontWeight: 'bold' }}>The Eternal Gallery</h1>
        <p style={{ marginTop: '1rem', fontSize: '1.25rem', color: '#ccc' }}>
          Museum-grade gemstone masterpieces — curated by nature, immortalized by art.
        </p>
      </section>
      <section style={{ backgroundColor: '#111', padding: '4rem 2rem' }}>
        <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>About</h2>
        <p style={{ maxWidth: '600px', margin: '0 auto', color: '#aaa' }}>
          The Eternal Gallery curates ultra-rare gemstone pieces that stand at the intersection of nature and timeless design.
        </p>
      </section>
    </div>
  );
}
